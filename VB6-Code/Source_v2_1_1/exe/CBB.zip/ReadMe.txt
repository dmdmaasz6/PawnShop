Version 2.1.0 Changes:
 - Rearrange "Stock Section" buttons
 - Add Realizable Income Button to "Stock Section"
 - Add Report for REalizable Income
Version 2.0.0 Changes:
 - Compiled and build on Win7 - 64 Bit machine
 - No code changes.
Version 1.4.2 Changes::
 - Increase arrItems from 1000 to 10000 for out-of-bounds error. (frmCustomerHistory.frmload)
Version 1.4.1 Changes:
 - Changes call from cmdReportandMove to PawnStockToFloor(pncid As Long) (Intgerer changes to Long)
Version 1.4.0 Changes:
 - PncID changes from Intgerer to Long, for overflow error.
